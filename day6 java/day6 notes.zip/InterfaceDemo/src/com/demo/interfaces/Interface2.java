package com.demo.interfaces;

public interface Interface2 {
	void m21();
	int m22();

}
