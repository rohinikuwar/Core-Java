package com.demo.interfaces;

public interface Interface4 {
void m41();
void m42();
}
