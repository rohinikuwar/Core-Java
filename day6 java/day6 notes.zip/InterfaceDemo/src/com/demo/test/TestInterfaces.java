package com.demo.test;

import com.demo.service.MyClass;

public class TestInterfaces {

	public static void main(String[] args) {
		MyClass ob=new MyClass();
		ob.defaultf1();
		ob.m11();
		//ob.i=45;
	}

}
